export class ListAllEntities {
  limit: number;
}
